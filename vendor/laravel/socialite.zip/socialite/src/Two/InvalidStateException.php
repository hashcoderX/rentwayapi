<?php

namespace Laravel\Socialite\Two;

use InvalidArgumentException;

class InvalidStateException extends InvalidArgumentException
{
    //
}
